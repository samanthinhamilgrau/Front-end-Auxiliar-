function searchState() {
    var estadoInput = document.getElementById('estadoInput').value.toUpperCase();
    var resultDiv = document.getElementById('result');
    resultDiv.innerHTML = '';

    // Adicione mais estados conforme necessário
    var estados = {
        'SP': { capital: 'São Paulo', regiao: 'Sudeste' },
        'RJ': { capital: 'Rio de Janeiro', regiao: 'Sudeste' },
        'MG': { capital: 'Belo Horizonte', regiao: 'Sudeste' },
        'BA': { capital: 'Salvador', regiao: 'Nordeste' },
        'RS': { capital: 'Porto Alegre', regiao: 'Sul' },
        // Adicione mais estados aqui
    };

    if (estados.hasOwnProperty(estadoInput)) {
        var estadoInfo = estados[estadoInput];
        resultDiv.innerHTML = `<p><strong>Estado:</strong> ${estadoInput}</p>
                               <p><strong>Capital:</strong> ${estadoInfo.capital}</p>
                               <p><strong>Região:</strong> ${estadoInfo.regiao}</p>`;
    } else {
        resultDiv.innerHTML = '<p>Estado não encontrado.</p>';
    }
}
